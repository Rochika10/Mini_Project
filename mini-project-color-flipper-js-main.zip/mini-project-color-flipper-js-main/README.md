# Color Flipper

Change the background of the website on clicking button with a random color.

Preview: https://yuvraj3905.github.io/mini-project-color-flipper-js/
